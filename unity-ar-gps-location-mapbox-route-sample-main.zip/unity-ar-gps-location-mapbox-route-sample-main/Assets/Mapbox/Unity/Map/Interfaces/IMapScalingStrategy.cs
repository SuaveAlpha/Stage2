namespace Mapbox.Unity.Map.Interfaces
{
	public interface IMapScalingStrategy
	{
		void SetUpScaling(AbstractMap map);
	}
}
