Thank you for downloading the Mapbox Unity SDK (for Unity 2017.4.2+)!


Getting started: https://www.mapbox.com/unity-sdk/overview/#getting-started

Tutorials: https://www.mapbox.com/unity-sdk/tutorials/

Known Issues: https://www.mapbox.com/mapbox-unity-sdk/docs/02-known-issues.html

API: https://www.mapbox.com/mapbox-unity-sdk/api/



Current version: 2.0.1, as of December 21st, 2018

Changelog: https://www.mapbox.com/mapbox-unity-sdk/docs/05-changelog.html

IMPORTANT:
If you intend to deploy for Android, please set your minimum version to 15 in PlayerSettings.
For iOS, please set your minimum version to 8.

If you have any other issues or feedback, please contact us at https://www.mapbox.com/contact/
or check our public repository: https://github.com/mapbox/mapbox-unity-sdk/issues.
