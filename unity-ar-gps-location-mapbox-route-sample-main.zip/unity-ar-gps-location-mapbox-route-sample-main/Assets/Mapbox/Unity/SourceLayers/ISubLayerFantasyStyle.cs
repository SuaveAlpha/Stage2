﻿namespace Mapbox.Unity.Map
{
	public interface ISubLayerFantasyStyle : ISubLayerStyle
	{
	}

}


