namespace Mapbox.Unity.Map.Interfaces
{
	public interface IMapPlacementStrategy
	{
		void SetUpPlacement(AbstractMap map);
	}
}
