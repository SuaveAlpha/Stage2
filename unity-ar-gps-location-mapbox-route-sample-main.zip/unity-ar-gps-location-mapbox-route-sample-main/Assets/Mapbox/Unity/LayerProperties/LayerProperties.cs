﻿using UnityEngine;
using Mapbox.Unity.MeshGeneration.Modifiers;
namespace Mapbox.Unity.Map
{
	public abstract class LayerProperties : MapboxDataProperty
	{
	}
}
