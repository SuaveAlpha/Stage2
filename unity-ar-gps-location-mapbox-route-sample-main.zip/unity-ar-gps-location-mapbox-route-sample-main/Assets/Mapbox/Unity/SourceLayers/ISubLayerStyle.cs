﻿namespace Mapbox.Unity.Map
{
	public interface ISubLayerStyle
	{
		void SetAsStyle();
	}

}


