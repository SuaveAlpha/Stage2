﻿public interface IElevationBasedTerrainStrategy
{

}