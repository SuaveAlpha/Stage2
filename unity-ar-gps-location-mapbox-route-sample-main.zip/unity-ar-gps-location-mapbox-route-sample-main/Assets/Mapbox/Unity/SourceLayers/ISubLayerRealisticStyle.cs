﻿namespace Mapbox.Unity.Map
{
	public interface ISubLayerRealisticStyle : ISubLayerStyle
	{

	}

}


